*******************************************

Ludwig dumped you.

Your heart is broken, but your spear is not.

Climb!

*******************************************

Final Title: Getting over... Ludwig
Prototyping Title: SpearGame
Fake Working Title: Spearstruck

Version: 1.1 - now with sound (sounds from freesound.org, menu loop by Sunsai: https://freesound.org/people/Sunsai/ )

​A difficult and in parts punishing game about climbing a cliff using a spear.

Made for the Ludwig Jam, October 2021, in approximately 90h of work.

Xbox type controller support (XInput) and keyboard controls.  Controls are as you would expect, direction keys and space to jump.

No saving/ loading of any kind including settings. Currently there is NO SOUND either, sorry!

To apply a new screen resolution have that menu item highlighted and press Enter/ Space or (A) on the controller.

There is no mouse support in the menu for now.

Unzip the archive instead of trying to start the exe from the Zip file, it might not work otherwise.

Have fun and good luck!

Superku